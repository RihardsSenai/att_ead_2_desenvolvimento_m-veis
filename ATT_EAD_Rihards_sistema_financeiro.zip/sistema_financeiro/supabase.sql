create table public.categorias (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  created_at timestamptz not null default now()
);

create table public.transacoes (
  id uuid primary key default gen_random_uuid(),
  descricao text not null,
  valor numeric not null,
  tipo text not null,
  categoria_id uuid references public.categorias(id) on delete set null,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.categorias enable row level security;
alter table public.transacoes enable row level security;

create policy "categorias_select" on public.categorias
  for select to authenticated using (true);

create policy "categorias_insert" on public.categorias
  for insert to authenticated with check (true);

create policy "transacoes_select" on public.transacoes
  for select to authenticated using (user_id = auth.uid());

create policy "transacoes_insert" on public.transacoes
  for insert to authenticated with check (user_id = auth.uid());

create policy "transacoes_update" on public.transacoes
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "transacoes_delete" on public.transacoes
  for delete to authenticated using (user_id = auth.uid());

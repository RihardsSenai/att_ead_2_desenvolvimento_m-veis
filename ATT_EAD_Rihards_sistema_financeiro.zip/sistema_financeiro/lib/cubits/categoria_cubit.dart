import 'package:flutter_bloc/flutter_bloc.dart';
import 'categoria_state.dart';
import '../models/categoria.dart';
import '../repositories/categoria_repository.dart';

class CategoriaCubit extends Cubit<CategoriaState> {
  List<Categoria> _categorias = [];
  final CategoriaRepository repository;

  CategoriaCubit({required this.repository}) : super(CategoriaInitial());

  Future<void> carregarCategorias() async {
    emit(CategoriaLoading(_categorias));

    try {
      _categorias = await repository.buscarCategorias();
      emit(CategoriaLoaded(List.unmodifiable(_categorias)));
    } catch (e) {
      emit(CategoriaError('Erro ao carregar categorias. $e', _categorias));
    }
  }

  Future<void> adicionarCategoria(String nome) async {
    if (nome.trim().isEmpty) {
      emit(CategoriaError('Informe o nome da categoria.', _categorias));
      return;
    }

    emit(CategoriaLoading(_categorias));

    try {
      final novaCategoria = await repository.criarCategoria(
        Categoria(id: '', nome: nome.trim())
      );
      _categorias = [..._categorias, novaCategoria];
      _categorias.sort((a, b) => a.nome.toLowerCase().compareTo(b.nome.toLowerCase()));
      emit(CategoriaSuccess('Categoria salva com sucesso!', List.unmodifiable(_categorias)));
    } catch (e) {
      emit(CategoriaError('Falha ao salvar a categoria. $e', _categorias));
    }
  }

}

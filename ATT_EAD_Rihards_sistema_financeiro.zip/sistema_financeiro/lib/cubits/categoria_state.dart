import '../models/categoria.dart';

abstract class CategoriaState {
  final List<Categoria> categorias;
  CategoriaState(this.categorias);
}

class CategoriaInitial extends CategoriaState {
  CategoriaInitial() : super(const []);
}

class CategoriaLoading extends CategoriaState {
  CategoriaLoading(super.categorias);
}

class CategoriaLoaded extends CategoriaState {
  CategoriaLoaded(super.categorias);
}

class CategoriaSuccess extends CategoriaState {
  final String mensagem;
  CategoriaSuccess(this.mensagem, super.categorias);
}

class CategoriaError extends CategoriaState {
  final String erro;
  CategoriaError(this.erro, super.categorias);
}
